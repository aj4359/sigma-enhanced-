import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { TrendingUp, TrendingDown, DollarSign, BarChart3, Bot, Zap, Target, Award } from 'lucide-react'
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts'
import './App.css'

const COLORS = ['#00ff88', '#0088ff', '#ff8800', '#ff0088', '#8800ff']

// Impressive demo data for TikTok appeal
const demoPortfolioData = [
  { name: 'BTC', value: 45, amount: 125.7, price: 1247500, color: '#f7931a' },
  { name: 'ETH', value: 25, amount: 892.3, price: 693750, color: '#627eea' },
  { name: 'SOL', value: 15, amount: 8420.1, price: 416250, color: '#9945ff' },
  { name: 'MATIC', value: 10, amount: 125000, price: 277500, color: '#8247e5' },
  { name: 'Others', value: 5, amount: 0, price: 138750, color: '#64748b' }
]

const performanceData = [
  { time: '9:00', value: 2750000 },
  { time: '10:00', value: 2820000 },
  { time: '11:00', value: 2890000 },
  { time: '12:00', value: 2950000 },
  { time: '13:00', value: 3100000 },
  { time: '14:00', value: 3250000 },
  { time: '15:00', value: 3180000 },
  { time: '16:00', value: 3350000 },
]

const aiSignals = [
  { symbol: 'BTC/USDT', action: 'BUY', confidence: 94, profit: '+$47,250' },
  { symbol: 'ETH/USDT', action: 'SELL', confidence: 89, profit: '+$23,100' },
  { symbol: 'SOL/USDT', action: 'BUY', confidence: 92, profit: '+$18,750' },
  { symbol: 'MATIC/USDT', action: 'HOLD', confidence: 87, profit: '+$12,400' }
]

function App() {
  const [currentView, setCurrentView] = useState('portfolio')
  const [isDemo, setIsDemo] = useState(true)
  const [showAIChat, setShowAIChat] = useState(false)
  const [chatMessages, setChatMessages] = useState([
    { type: 'ai', message: "Hi! I'm SIGMA AI. I can explain how our platform works and help you understand trading concepts. What would you like to know?" }
  ])
  const [userInput, setUserInput] = useState('')

  const totalValue = 2775000
  const totalGains = 525000
  const gainsPercentage = 23.3

  const handleAIChat = (message) => {
    setChatMessages(prev => [...prev, { type: 'user', message }])
    
    // Simple AI responses for demo
    setTimeout(() => {
      let response = "I'm here to help! "
      if (message.toLowerCase().includes('sigma') || message.toLowerCase().includes('what')) {
        response = "SIGMA is an AI-powered trading platform that uses advanced algorithms to analyze market data and provide high-confidence trading signals. We help both beginners and pros make profitable trades with our institutional-grade technology."
      } else if (message.toLowerCase().includes('how') || message.toLowerCase().includes('work')) {
        response = "SIGMA works by analyzing thousands of market indicators in real-time using machine learning. Our AI identifies profitable opportunities and sends you signals with confidence scores. You can trade manually or let our AI execute trades automatically."
      } else if (message.toLowerCase().includes('profit') || message.toLowerCase().includes('money')) {
        response = "Our users typically see 15-35% monthly returns. The demo shows a $2.7M portfolio with $525K gains (23.3% return). Results vary, but our AI's 94% accuracy rate helps maximize profits while minimizing risks."
      } else if (message.toLowerCase().includes('safe') || message.toLowerCase().includes('risk')) {
        response = "SIGMA uses advanced risk management with stop-losses, position sizing, and diversification. Our AI monitors market volatility 24/7 and adjusts strategies automatically to protect your capital."
      } else {
        response = "That's a great question! SIGMA combines institutional-grade AI with user-friendly interfaces. Our platform is designed for everyone - from crypto beginners to professional traders. Would you like to know more about our AI signals or risk management?"
      }
      setChatMessages(prev => [...prev, { type: 'ai', message: response }])
    }, 1000)
    setUserInput('')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-3 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 sm:space-x-4">
              <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
                SIGMA
              </div>
              <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                DEMO
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowAIChat(!showAIChat)}
                className="border-purple-500/50 text-purple-300 hover:bg-purple-500/20 px-2 sm:px-3"
              >
                <Bot className="w-4 h-4 sm:mr-2" />
                <span className="hidden sm:inline">AI Assistant</span>
              </Button>
              <Button className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-xs sm:text-sm px-2 sm:px-4">
                <span className="hidden sm:inline">Upgrade to Real Trading</span>
                <span className="sm:hidden">Upgrade</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-3 py-4 sm:px-4 sm:py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 sm:gap-6">
          {/* Navigation */}
          <div className="lg:col-span-1 order-2 lg:order-1">
            <Card className="bg-black/40 border-white/10 backdrop-blur-sm">
              <CardContent className="p-3 sm:p-4">
                <nav className="flex lg:flex-col space-x-2 lg:space-x-0 lg:space-y-2 overflow-x-auto lg:overflow-x-visible">
                  {[
                    { id: 'portfolio', label: 'Portfolio', icon: BarChart3 },
                    { id: 'signals', label: 'AI Signals', icon: Zap },
                    { id: 'performance', label: 'Performance', icon: TrendingUp },
                  ].map((item) => (
                    <Button
                      key={item.id}
                      variant={currentView === item.id ? "default" : "ghost"}
                      className={`flex-shrink-0 lg:w-full justify-start text-sm ${
                        currentView === item.id 
                          ? 'bg-gradient-to-r from-green-500 to-blue-500' 
                          : 'text-gray-300 hover:text-white hover:bg-white/10'
                      }`}
                      onClick={() => setCurrentView(item.id)}
                    >
                      <item.icon className="w-4 h-4 mr-1 sm:mr-2" />
                      <span className="hidden sm:inline lg:inline">{item.label}</span>
                    </Button>
                  ))}
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 order-1 lg:order-2">
            {currentView === 'portfolio' && (
              <div className="space-y-4 sm:space-y-6">
                {/* Portfolio Overview */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                  <Card className="bg-black/40 border-white/10 backdrop-blur-sm">
                    <CardContent className="p-4 sm:p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-xs sm:text-sm text-gray-400">Total Portfolio Value</p>
                          <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-green-400">
                            ${(totalValue/1000000).toFixed(2)}M
                          </p>
                        </div>
                        <DollarSign className="w-6 h-6 sm:w-8 sm:h-8 text-green-400" />
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-black/40 border-white/10 backdrop-blur-sm">
                    <CardContent className="p-4 sm:p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-xs sm:text-sm text-gray-400">Total P&L</p>
                          <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-green-400">
                            +${(totalGains/1000).toFixed(0)}K
                          </p>
                        </div>
                        <TrendingUp className="w-6 h-6 sm:w-8 sm:h-8 text-green-400" />
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-black/40 border-white/10 backdrop-blur-sm sm:col-span-2 lg:col-span-1">
                    <CardContent className="p-4 sm:p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-xs sm:text-sm text-gray-400">Return Rate</p>
                          <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-green-400">
                            +{gainsPercentage}%
                          </p>
                        </div>
                        <Target className="w-6 h-6 sm:w-8 sm:h-8 text-green-400" />
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Asset Allocation */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                  <Card className="bg-black/40 border-white/10 backdrop-blur-sm">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-white text-lg">Asset Allocation</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-48 sm:h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={demoPortfolioData}
                              cx="50%"
                              cy="50%"
                              outerRadius={60}
                              fill="#8884d8"
                              dataKey="value"
                            >
                              {demoPortfolioData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-black/40 border-white/10 backdrop-blur-sm">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-white text-lg">Holdings</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {demoPortfolioData.map((asset, index) => (
                          <div key={asset.name} className="flex items-center justify-between p-2 sm:p-3 rounded-lg bg-white/5">
                            <div className="flex items-center space-x-2 sm:space-x-3">
                              <div 
                                className="w-3 h-3 rounded-full" 
                                style={{ backgroundColor: COLORS[index % COLORS.length] }}
                              />
                              <div>
                                <p className="font-semibold text-white text-sm sm:text-base">{asset.name}</p>
                                <p className="text-xs sm:text-sm text-gray-400">{asset.amount} {asset.name}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-semibold text-green-400 text-sm sm:text-base">
                                ${(asset.price/1000).toFixed(0)}K
                              </p>
                              <p className="text-xs sm:text-sm text-gray-400">{asset.value}%</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {currentView === 'signals' && (
              <div className="space-y-4 sm:space-y-6">
                <Card className="bg-black/40 border-white/10 backdrop-blur-sm">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white flex items-center text-lg">
                      <Zap className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-yellow-400" />
                      Live AI Trading Signals
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 sm:space-y-4">
                      {aiSignals.map((signal, index) => (
                        <div key={index} className="flex items-center justify-between p-3 sm:p-4 rounded-lg bg-white/5 border border-white/10">
                          <div className="flex items-center space-x-3 sm:space-x-4">
                            <Badge 
                              variant={signal.action === 'BUY' ? 'default' : signal.action === 'SELL' ? 'destructive' : 'secondary'}
                              className={`text-xs ${
                                signal.action === 'BUY' 
                                  ? 'bg-green-500/20 text-green-400 border-green-500/30' 
                                  : signal.action === 'SELL'
                                  ? 'bg-red-500/20 text-red-400 border-red-500/30'
                                  : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                              }`}
                            >
                              {signal.action}
                            </Badge>
                            <div>
                              <p className="font-semibold text-white text-sm sm:text-base">{signal.symbol}</p>
                              <p className="text-xs sm:text-sm text-gray-400">Confidence: {signal.confidence}%</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-green-400 text-sm sm:text-base">{signal.profit}</p>
                            <p className="text-xs sm:text-sm text-gray-400">Projected</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {currentView === 'performance' && (
              <div className="space-y-4 sm:space-y-6">
                <Card className="bg-black/40 border-white/10 backdrop-blur-sm">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-lg">Portfolio Performance Today</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-48 sm:h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={performanceData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                          <XAxis dataKey="time" stroke="#9CA3AF" fontSize={12} />
                          <YAxis stroke="#9CA3AF" fontSize={12} />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#1F2937', 
                              border: '1px solid #374151',
                              borderRadius: '8px',
                              fontSize: '12px'
                            }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="value" 
                            stroke="#10B981" 
                            strokeWidth={2}
                            dot={{ fill: '#10B981', strokeWidth: 2, r: 3 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* AI Chat Modal */}
      {showAIChat && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4">
          <Card className="w-full max-w-sm sm:max-w-md bg-black/80 border-white/20 backdrop-blur-sm max-h-[90vh] flex flex-col">
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-white flex items-center text-lg">
                <Bot className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-purple-400" />
                SIGMA AI Assistant
              </CardTitle>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowAIChat(false)}
                className="text-gray-400 hover:text-white h-8 w-8 p-0"
              >
                ×
              </Button>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 flex-1 flex flex-col">
              <div className="h-48 sm:h-64 overflow-y-auto space-y-2 sm:space-y-3 p-2 flex-1">
                {chatMessages.map((msg, index) => (
                  <div key={index} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-2 sm:p-3 rounded-lg ${
                      msg.type === 'user' 
                        ? 'bg-blue-500 text-white' 
                        : 'bg-gray-700 text-gray-100'
                    }`}>
                      <p className="text-xs sm:text-sm">{msg.message}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && userInput.trim() && handleAIChat(userInput)}
                  placeholder="Ask me about SIGMA..."
                  className="flex-1 px-2 sm:px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm"
                />
                <Button 
                  onClick={() => userInput.trim() && handleAIChat(userInput)}
                  className="bg-purple-500 hover:bg-purple-600 px-3 sm:px-4"
                  size="sm"
                >
                  Send
                </Button>
              </div>
              <div className="flex flex-wrap gap-1 sm:gap-2">
                {[
                  "What is SIGMA?",
                  "How does it work?",
                  "Is it profitable?",
                  "Is it safe?"
                ].map((question) => (
                  <Button
                    key={question}
                    variant="outline"
                    size="sm"
                    onClick={() => handleAIChat(question)}
                    className="text-xs border-white/20 text-gray-300 hover:bg-white/10 px-2 py-1 h-auto"
                  >
                    {question}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Watermark */}
      <div className="fixed bottom-2 right-2 sm:bottom-4 sm:right-4 text-xs text-gray-500 bg-black/20 backdrop-blur-sm px-2 sm:px-3 py-1 rounded-full border border-white/10">
        Built by Anthony Johnson - TA GuruLabs
      </div>
    </div>
  )
}

export default App

